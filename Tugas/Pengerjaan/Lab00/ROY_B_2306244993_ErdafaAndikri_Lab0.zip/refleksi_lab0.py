#membuat user input nama, tanggal lahir, dan fun fact
nama = input("Nama: ")
tanggal_lahir = input("Tanggal lahir: ")
fun_fact = input("Fun fact: ")

#mengeprint perkenalan dengan apa yang user input
print("haloo teman-teman!! Perkenalkan namaku " + nama + ", aku lahir di tanggal " + tanggal_lahir + ". Tau gak fun fact aku itu " + fun_fact) 
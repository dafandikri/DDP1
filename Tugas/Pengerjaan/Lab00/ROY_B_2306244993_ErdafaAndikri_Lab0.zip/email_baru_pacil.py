#cetak judul program ini
print("Buat Email Baru Khusus Anak Pacil")

#melakukan input untuk info yang akan digunakan dalam pembuatan email
nama_depan = input("Nama Depan: ")
nama_panggilan = input("Nama Panggilan: ")
tanggal_lahir = input("Tanggal Lahir: ")

#mencetak ucapan selamat datang sesuai dengan nama yang di input
print("Halo " + nama_depan + ", selamat datang di Fasilkom!")

#mencetak email baru untuk anak pacil
print("Email kamu adalah " + nama_depan + "." + nama_panggilan + tanggal_lahir + "@ui.ac.id")